<?php 
// Template Name: Sobre
get_header(); ?>

<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

<section class="container sobre">
	<h2 class="subtitulo"><?php the_title(); ?></h2>

	<div class="grid-8">
		<img src="<?php the_field('photo_about'); ?>" alt="<?php the_field('alt_photo'); ?>">
	</div>

<?php if(have_rows('history_')): while(have_rows('history_')) : the_row(); ?>
	
	<div class="grid-8">
		<h2><?php the_sub_field('title_history'); ?></h2>
		<p><?php the_sub_field('text_history'); ?></p>
	</div>

<?php endwhile; else : endif; ?>

	
</section>

<?php endwhile; else: endif; ?>

<?php get_footer(); ?>